for a in range(1,101):
    if a % 7>0 :
        if '7' not in str(a):
            print (a)
    else:
        continue
        
